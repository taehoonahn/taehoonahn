select * from member;
select * from pets;
select * from imageboard;
select * from comments;

delete from member;

select * from imageboard where ROWNUM >= 11 and ROWNUM <= 20;